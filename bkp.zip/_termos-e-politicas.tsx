import React, { useMemo } from 'react';

import { GetStaticProps } from 'next';

import api from '@/services/api';

import IPageProps from '@/interfaces/pages/PageProps';

import BannerPages from '@/components/BannerPages';
import Footer from '@/components/Footer';
import Header from '@/components/Header';
import Metadata from '@/components/Metadata';

import { Container } from '@/styles/pages/TermsAndPolicies';

const TermsAndPolicies: React.FC<IPageProps<null>> = ({ data }) => {
  // const props = data?.data?.props ? JSON.parse(data?.data?.props) : undefined;
  // const content = props
  //   ? JSON.parse(props?.find(x => x.key === 'page_content').value)
  //   : '';

  return (
    <>
      <Metadata
        data={{
          ...data?.data?.metadata,
          image: data.data?.image,
          index: true,
        }}
      />

      <Header />
      <Container>
        <BannerPages
          data={{
            img: '/assets/terms-and-policies/terms-and-policies.webp',
            title: 'Termos e políticas',
            description:
              'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Massa lacus in at sagittis amet elit id augue. Auctor dolor ullamcorper in auctor suscipit. Nulla.',
          }}
        />

        <section className="content">
          {/* {content?.terms.map(item => (
            <>
              {item.title && <h3>{item.title}</h3>}

              {item.text && <p>{item.text}</p>}
            </>
          ))} */}
        </section>
      </Container>
      <Footer />
    </>
  );
};

export default TermsAndPolicies;

export const getStaticProps: GetStaticProps = async () => {
  // const response = await api.get('/pages/termos');

  return {
    props: {
      data: [],
    },
    revalidate: 86400, // 24h
  };
};
