import React, { useCallback, useRef, useState } from 'react';
import { AiOutlineEye, AiOutlineEyeInvisible } from 'react-icons/ai';

import { FormHandles } from '@unform/core';
import { Form } from '@unform/web';

import { getCookie } from 'cookies-next';
import { GetServerSideProps } from 'next';
import Link from 'next/link';
import { useRouter } from 'next/router';

import Footer from '@/components/Footer';
import Button from '@/components/Form/Button';
import Input from '@/components/Form/InputAuth';
import InputMask from '@/components/Form/InputMaskAuth';
import Select from '@/components/Form/SelectAuth';
import Header from '@/components/Header';
import MenuLateral from '@/components/MenuLateral';
import Metadata from '@/components/Metadata';

import { Container } from '@/styles/pages/MyAccount/InformationPeople';

const Organizer: React.FC = () => {
  const router = useRouter();

  const formRef = useRef<FormHandles>(null);

  const [secureTextEntry, setSecureTextEntry] = useState(true);
  const [maskPhone, setMaskPhone] = useState('(99) 99999-9999');

  const handleSubmit = useCallback(data => {}, []);
  return (
    <>
      <Metadata data={{ title: 'Minha conta' }} />

      <Header />

      <main>
        <Container>
          <section>
            <MenuLateral screen="organizador" />

            <div className="content">
              <div className="buttons-header">
                <button type="button" onClick={() => router.back()}>
                  Cancelar
                </button>
                <Button
                  typeButton="primary"
                  onClick={() => formRef.current.submitForm()}
                >
                  Salvar Alterações
                </Button>
              </div>
              <div className="content-form">
                <h5>Dados do organizador</h5>

                <Form ref={formRef} onSubmit={handleSubmit}>
                  <div className="row">
                    <Input
                      id="name"
                      name="name"
                      placeholder="Nome Completo"
                      label="Nome Completo"
                      width={65.5}
                      typeVariation="secundary"
                    />
                    <Input
                      id="name"
                      name="name"
                      placeholder="Nome Completo"
                      label="Data de nascimento"
                      type="date"
                      width={30.5}
                      typeVariation="secundary"
                    />
                  </div>

                  <div className="row">
                    <InputMask
                      id="cpf"
                      name="cpf"
                      label="CPF"
                      width={48}
                      mask="999.999.999-99"
                      typeVariation="secundary"
                      placeholder="CPF"
                    />

                    <InputMask
                      id="phone"
                      name="phone"
                      label="Telefone"
                      placeholder="Telefone"
                      width={48}
                      typeVariation="secundary"
                      type="tel"
                      mask={maskPhone}
                      onBlur={e => {
                        if (e.target.value.replace('_', '').length === 14) {
                          setMaskPhone('(99) 9999-9999');
                        }
                      }}
                      onFocus={e => {
                        if (e.target.value.replace('_', '').length === 14) {
                          setMaskPhone('(99) 99999-9999');
                        }
                      }}
                    />
                  </div>

                  <div className="row">
                    <Select
                      name="state"
                      label="Estado"
                      options={[
                        {
                          id: 1,
                          value: 'string',
                          label: 'string',
                        },
                      ]}
                      typeVariation="secundary"
                      width={30}
                    />
                    <Select
                      name="city"
                      label="Cidade"
                      options={[
                        {
                          id: 1,
                          value: 'string',
                          label: 'string',
                        },
                      ]}
                      typeVariation="secundary"
                      width={65.5}
                    />
                  </div>
                  <div className="row">
                    <Input
                      id="email"
                      name="email"
                      placeholder="Email"
                      label="Email"
                      width={48}
                      typeVariation="secundary"
                    />
                    <Input
                      name="password"
                      id="password"
                      label="Senha"
                      placeholder="Senha"
                      type={secureTextEntry ? 'password' : 'text'}
                      width={48}
                      typeVariation="secundary"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setSecureTextEntry(!secureTextEntry);
                        }}
                      >
                        {secureTextEntry ? (
                          <AiOutlineEye size={20} />
                        ) : (
                          <AiOutlineEyeInvisible size={20} />
                        )}
                      </button>
                    </Input>
                  </div>
                </Form>

                <div className="link">
                  <Link href="/">Alterar Senha </Link>
                </div>
              </div>
            </div>
          </section>
        </Container>
      </main>
      <Footer />
    </>
  );
};

export default Organizer;

export const getServerSideProps: GetServerSideProps = async ctx => {
  const isAuth = getCookie('easy.isAuth', ctx);

  if (!isAuth) {
    return {
      redirect: {
        destination: '/login',
        permanent: false,
      },
    };
  }

  return {
    props: {},
  };
};
