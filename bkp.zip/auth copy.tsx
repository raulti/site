import jwtDecode from 'jwt-decode';
import React, {
  createContext,
  useCallback,
  useState,
  useContext,
  useEffect,
} from 'react';

import { deleteCookie, setCookie } from 'cookies-next';
import Router from 'next/router';

import api from '../services/api';

import {
  AuthContextData,
  AuthState,
  IAuthProvider,
  IUser,
} from '@/interfaces/hooks/IAuth';

interface IDecoded {
  id: number;
  data: IUser;
}

const AuthContext = createContext<AuthContextData>({} as AuthContextData);

export const AuthProvider: React.FC<IAuthProvider> = ({
  dataAuth,
  children,
}) => {
  const [data, setData] = useState<AuthState>(() => {
    if (dataAuth.user && dataAuth.token) {
      api.defaults.headers.Authorization = `Bearer ${dataAuth.token?.toString()}`;

      return {
        token: dataAuth.token,
        user: JSON.parse(dataAuth.user),
      };
    }

    return {} as AuthState;
  });

  const signIn = useCallback(async ({ email, password }) => {
    const response = await api.post('/login', { email, password });

    const { token } = response.data.data;

    const decoded: IDecoded = jwtDecode(token);

    setCookie('easy.isAuth', true);
    // setCookie('easy.keepConnected', keepConnected);
    setCookie('easy.token', token);
    setCookie('easy.user', decoded.data);

    api.defaults.headers.authorization = `Bearer ${token}`;

    setData({
      token,
      user: decoded.data,
    });
  }, []);

  const signOut = useCallback(() => {
    deleteCookie('easy.isAuth');
    deleteCookie('easy.token');
    deleteCookie('easy.user');
    // deleteCookie('easy.keepConnected');

    delete api.defaults.headers.Authorization;

    Router.replace('/');

    setData({} as AuthState);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user: data?.user,
        // userPermissions: permissions,
        signIn,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextData {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  return context;
}
